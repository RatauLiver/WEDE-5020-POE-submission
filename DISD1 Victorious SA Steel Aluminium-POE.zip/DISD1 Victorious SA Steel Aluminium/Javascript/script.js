const contactForm=document.getElementById("contactForm");
const submitButton=document.getElementById("submitButton");
const formstatu=document.getElementById("formStatus");
// administrator email
const adminEmail="liver644@gmail.com";

contactForm.addEventListener("submit",async function (event) {
    event.preventDefault();
    
  // Run the browser build in validation
  if(! contactForm.checkVisibility()){
    contactForm.reportValidity();
    return

  }

    //Extra validation form names and phones
    const name=document.getElementById("name").value.trim();
    const phone=document.getElementById("phone").value.trim();
    const message=document.getElementById("message").value.trim();

    const namePattern=
                    /^[A-Za-zÀ-ÖØ-ÖØ-ŷ][A-Za-zÀ-ÖØ-ÖØ-ŷ '\-]*$/;

    const phonePattern=/^\+?{[0-9()-]}{9,20}$/;
    if(!namePattern.test(name)){
        alert("Please enter a valid full name");
        return;
    }
    if(!phonePattern.test(phone)){
        alert("Please enter a valid phone number");
        return;
    }   

    if(message.length<10){
        alert("Your message must contain at atleast 10 characters");
        return;
    }

    // prevent repeated clicks while sending
    submitButton.disabled=true;
    submitButton.textContent="Sending...";
    formstatu.textContent="Submitting your message..";

    try {// send form data to submits AJAX endpoint
        const response =await fetch(
            "https://formsubmit.co/ajax/"+encodeURIComponent(adminEmail),
            {
                method:"POST",
                headers:{
                    "Content-Type":"application/json",
                    "Accept":"application/json"
                },
                body:JSON.stringify({
                    name:name,
                    email: document.getElementById("email").value.trim,
                    phone:phone,
                    subject:document.getElementById("subject").value,
                    message:message,
                    _subject:"New Website Contact Form Submission",
                    _template:"table"

                })
            }

        );
        const result=await response.json();
        //show succes in the service confirms acceptance
        if(
            response.ok&&
            (
                result.success===true||
                result.success==="true"

            )





        ){
            alert("your information has been sent successfully!");
            formstatu.textContent= "Thank you! Your message was submitted successfully.";
            contactForm.reset ();




        }else{

            throw new error(
                result.message||"The email service did not comfirm submission"
            );
        }

    } catch (error) {
        console.error("Form submission error:",error)
        formstatu.textContent="Sorry, your message could not be firmed.Please try again.";
        alert(
            "Message not confirmed. Please check your connection"+
            "or try again localStorage."

        );
        

    }finally{
        submitButton.disabled=false;
        submitButton.textContent="Send Message";


    }
        

});