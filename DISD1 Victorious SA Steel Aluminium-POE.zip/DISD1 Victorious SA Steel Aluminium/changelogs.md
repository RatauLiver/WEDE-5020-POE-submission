#Part 2
1. From the Lecuturer's feedback CSS file was linked well with HTML

2. For Final POE one is required to create a website using HTML , style the web pages using external CSS  then add HTML form so that one can be able to do form validation using javascript.

3. Also date and time will be added on all webpages

4. Search Engine Optimisation will be added in all webpages using meta tags


Reference
1. https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_js_lightbox
2. https://www.w3schools.com/tags/tag_meta.asp
3. https://www.w3schools.com/htmlcss/htmlcss_forms_validation.asp